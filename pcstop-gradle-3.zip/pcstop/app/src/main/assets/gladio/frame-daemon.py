#!/usr/bin/env python3
import socket
import struct
import sys
import time

PORT = 6000
DISPLAY = ":1"
MAGIC = 0x50435346
MAX_REQUEST_BYTES = 65535 * 4


def log(m):
    print("[frame-daemon] " + m, flush=True)


def recv_all(s, n):
    buf = b""
    while len(buf) < n:
        try:
            chunk = s.recv(n - len(buf))
        except Exception as e:
            log("recv erro: %s" % e)
            return b""
        if not chunk:
            return buf
        buf += chunk
    return buf


def find_window_by_name(dpy, win, name, depth=0):
    if depth > 5:
        return None
    try:
        tree = win.query_tree()
    except Exception:
        return None
    for child in tree.children:
        try:
            wm_name = child.get_wm_name()
            if wm_name and name.lower() in str(wm_name).lower():
                return child
        except Exception:
            pass
        found = find_window_by_name(dpy, child, name, depth + 1)
        if found:
            return found
    return None


def main():
    log("=== INICIANDO (PID %d) ===" % __import__('os').getpid())

    try:
        from Xlib import display, X
    except ImportError:
        log("ERRO: python3-xlib nao instalado")
        sys.exit(1)

    dpy = display.Display(DISPLAY)
    screen = dpy.screen()
    root = screen.root
    root_depth = screen.root_depth
    log("Xvfb %dx%d depth=%d" % (screen.width_in_pixels, screen.height_in_pixels, root_depth))

    root_gc = root.create_gc()

    s = None
    attempt = 0
    while s is None and attempt < 30:
        attempt += 1
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(2)
            s.connect(("127.0.0.1", PORT))
            s.settimeout(None)
            log("conectado! (tentativa %d)" % attempt)
        except Exception as e:
            try: s.close()
            except: pass
            s = None
            time.sleep(1)

    if s is None:
        log("FALHA: nao conseguiu conectar em %d" % PORT)
        sys.exit(1)

    total = 0
    target_window = None
    target_gc = None
    target_w = 0
    target_h = 0
    last_search = 0

    while True:
        try:
            header = recv_all(s, 16)
            if len(header) != 16:
                log("EOF header (%d bytes)" % len(header))
                break

            magic, w, h, fmt = struct.unpack(">IIII", header)
            if magic != MAGIC:
                log("magic errado: 0x%x" % magic)
                break

            size = w * h * 4
            data = recv_all(s, size)
            if len(data) != size:
                log("truncado %d/%d" % (len(data), size))
                break

            bgra = bytearray(size)
            for i in range(0, size, 4):
                bgra[i]     = data[i]
                bgra[i + 1] = data[i + 1]
                bgra[i + 2] = data[i + 2]
                bgra[i + 3] = 0xFF

            # Redetecta janela a cada 1s
            now = time.time()
            if now - last_search > 1.0:
                last_search = now
                w_glx = find_window_by_name(dpy, root, "glxgears")
                if w_glx:
                    if target_window is None or target_window.id != w_glx.id:
                        try:
                            gc = w_glx.create_gc()
                            geom = w_glx.get_geometry()
                            target_window = w_glx
                            target_gc = gc
                            target_w = geom.width
                            target_h = geom.height
                            log("janela glxgears: id=%s %dx%d" % (w_glx.id, geom.width, geom.height))
                        except Exception as e:
                            log("erro ao criar GC: %s" % e)
                            target_window = None
                            target_gc = None
                else:
                    if target_window is not None:
                        log("janela sumiu")
                    target_window = None
                    target_gc = None
                    target_w = 0
                    target_h = 0

            if target_window and target_gc:
                dest = target_window
                gc = target_gc
                dest_label = "janela"
                # Clip pra caber na janela
                fw = min(w, target_w)
                fh = min(h, target_h)
            else:
                dest = root
                gc = root_gc
                dest_label = "root"
                fw = w
                fh = h

            bytes_per_row_full = w * 4
            bytes_per_row_dest = fw * 4
            max_rows = MAX_REQUEST_BYTES // bytes_per_row_dest
            if max_rows < 1:
                max_rows = 1

            ok = True
            y = 0
            while y < fh:
                rows = min(max_rows, fh - y)
                # Copia apenas os fw pixels de largura de cada linha
                strip = bytearray(rows * bytes_per_row_dest)
                for r in range(rows):
                    src_off = (y + r) * bytes_per_row_full
                    dst_off = r * bytes_per_row_dest
                    strip[dst_off:dst_off + bytes_per_row_dest] = \
                        bgra[src_off:src_off + bytes_per_row_dest]
                try:
                    dest.put_image(gc, 0, y, fw, rows, X.ZPixmap, root_depth, 0, bytes(strip))
                except Exception as e:
                    log("put_image erro (y=%d w=%d h=%d): %s" % (y, fw, rows, e))
                    target_window = None
                    target_gc = None
                    ok = False
                    break
                y += rows

            if ok:
                dpy.flush()

            total += 1
            if total == 1 or total % 120 == 0:
                log("frame %d (%dx%d -> %dx%d) -> %s" % (total, w, h, fw, fh, dest_label))
        except Exception as e:
            log("erro no loop: %s" % e)
            break

    log("saindo (total=%d)" % total)


if __name__ == "__main__":
    main()