#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>

typedef void* (*PFN_gpa)(const unsigned char*);

int wrapper_glXQueryExtension(void* dpy, int* e, int* ev) {
    fprintf(stderr, "[WRAP] glXQueryExtension -> TRUE\n");
    if (e) *e = 0;
    if (ev) *ev = 0;
    return 1;
}

int glXQueryExtension(void* dpy, int* e, int* ev) {
    return wrapper_glXQueryExtension(dpy, e, ev);
}

void* glXGetProcAddressARB(const unsigned char* name) {
    const char* n = (const char*)name;
    if (!n) return NULL;
    if (strcmp(n, "glXQueryExtension") == 0)
        return (void*)wrapper_glXQueryExtension;

    void* h = dlopen("/usr/lib/aarch64-linux-gnu/gladio/libgladio-internal.so", RTLD_LAZY);
    if (h) {
        PFN_gpa real = (PFN_gpa)dlsym(h, "glXGetProcAddressARB");
        if (real) {
            void* p = real(name);
            if (p) return p;
        }
        void* p2 = dlsym(h, n);
        if (p2) return p2;
    }
    void* p3 = dlsym(RTLD_DEFAULT, n);
    return p3;
}

void* glXGetProcAddress(const unsigned char* name) {
    return glXGetProcAddressARB(name);
}