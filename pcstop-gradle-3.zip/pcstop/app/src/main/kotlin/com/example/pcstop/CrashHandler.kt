package com.example.pcstop

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.*

object CrashHandler {
    fun setup(context: Context) {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, ex ->
            try {
                val sw = StringWriter()
                ex.printStackTrace(PrintWriter(sw))
                val stackTrace = sw.toString()

                val timestamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
                val logContent = """
                    === PCSTOP CRASH ===
                    Thread: ${thread.name}
                    Time: $timestamp
                    Device: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.SDK_INT})
                    
                    STACK TRACE:
                    $stackTrace
                """.trimIndent()

                val externalDir = File("/sdcard/pcstop-backup").apply { mkdirs() }
                File(externalDir, "crash-$timestamp.txt").writeText(logContent)

            } catch (_: Exception) {}
            defaultHandler?.uncaughtException(thread, ex)
        }
    }
}