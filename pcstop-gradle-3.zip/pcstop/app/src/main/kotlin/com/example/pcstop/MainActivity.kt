package com.example.pcstop

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private lateinit var containerList: MutableList<ContainerConfig>
    private lateinit var adapter: ContainerAdapter
    private lateinit var emptyView: TextView

    private val REQUEST_PICK_ROOTFS = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val listView = ListView(this)
        
        // Botão de importar rootfs manual
        val btnImportRootfs = Button(this).apply {
            text = "📂 IMPORTAR ROOTFS (.tar.gz)"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_GET_CONTENT)
                intent.type = "*/*"
                intent.addCategory(Intent.CATEGORY_OPENABLE)
                startActivityForResult(Intent.createChooser(intent, "Selecione o Rootfs (.tar.gz)"), REQUEST_PICK_ROOTFS)
            }
        }

        val btnCreate = Button(this).apply {
            text = "+ CRIAR NOVO AMBIENTE"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, ContainerConfigActivity::class.java))
            }
        }
        
        emptyView = TextView(this).apply {
            text = "Nenhum ambiente encontrado.\nCrie um novo!"
            textSize = 18f
            val padding = (32 * resources.displayMetrics.density).toInt()
            setPadding(padding, padding, padding, padding)
        }

        layout.addView(btnImportRootfs, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(emptyView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        layout.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        layout.addView(btnCreate, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        setContentView(layout)
        listView.emptyView = emptyView

        containerList = ContainerConfig.getAll(this).toMutableList()
        adapter = ContainerAdapter()
        listView.adapter = adapter
        
        adapter.onItemClick = { config ->
            val intent = Intent(this, XServerActivity::class.java)
            intent.putExtra("containerId", config.id)
            startActivity(intent)
        }

        adapter.onDeleteClick = { config ->
            AlertDialog.Builder(this)
                .setTitle("Apagar Ambiente")
                .setMessage("O ambiente \"${config.name}\" e todos os seus arquivos serão permanentemente apagados.")
                .setPositiveButton("Apagar") { _, _ ->
                    ContainerConfig.delete(this, config.id)
                    containerList.remove(config)
                    adapter.notifyDataSetChanged()
                    Toast.makeText(this, "Apagado", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PICK_ROOTFS && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                copyFileToAppStorage(uri)
            }
        }
    }

    private fun copyFileToAppStorage(uri: Uri) {
        try {
            val targetFile = File(getExternalFilesDir(null), "pcstop-rootfs.tar.gz")
            
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }
            
            Toast.makeText(this, "Rootfs importado com sucesso!\nCrie ou abra um ambiente.", Toast.LENGTH_LONG).show()
            
        } catch (e: Exception) {
            Toast.makeText(this, "Erro ao importar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        containerList.clear()
        containerList.addAll(ContainerConfig.getAll(this))
        adapter.notifyDataSetChanged()
    }

    inner class ContainerAdapter : BaseAdapter() {
        var onItemClick: ((ContainerConfig) -> Unit)? = null
        var onDeleteClick: ((ContainerConfig) -> Unit)? = null

        override fun getCount(): Int = containerList.size
        override fun getItem(position: Int): Any = containerList[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val layout = LinearLayout(parent?.context).apply {
                orientation = LinearLayout.HORIZONTAL
                val padding = (16 * resources.displayMetrics.density).toInt()
                setPadding(padding, padding, padding, padding)
            }
            
            val config = containerList[position]
            
            val nameText = TextView(parent?.context).apply {
                text = config.name
                textSize = 18f
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            
            val btnPlay = Button(parent?.context).apply {
                text = "PLAY"
                setOnClickListener { onItemClick?.invoke(config) }
            }
            
            val btnDelete = Button(parent?.context).apply {
                text = "X"
                setOnClickListener { onDeleteClick?.invoke(config) }
            }

            layout.addView(nameText)
            layout.addView(btnPlay)
            layout.addView(btnDelete)
            return layout
        }
    }
}