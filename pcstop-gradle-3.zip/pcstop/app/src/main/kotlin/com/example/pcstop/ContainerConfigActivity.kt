package com.example.pcstop

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class ContainerConfigActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val padding = (32 * resources.displayMetrics.density).toInt()
            setPadding(padding, padding, padding, padding)
        }

        val label = TextView(this).apply { text = "Nome do Ambiente:" }
        val etName = EditText(this).apply { 
            setText("Debian Linux") 
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        
        val btnSave = Button(this).apply {
            text = "SALVAR"
            setOnClickListener {
                val name = etName.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this@ContainerConfigActivity, "Digite um nome!", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                
                val id = System.currentTimeMillis().toString()
                val config = ContainerConfig(id, name)
                config.save(this@ContainerConfigActivity)
                
                finish()
            }
        }

        layout.addView(label)
        layout.addView(etName)
        layout.addView(btnSave)
        setContentView(layout)
    }
}