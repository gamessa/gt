package com.example.pcstop

import android.app.Application
import android.util.Log
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PCStopApp : Application() {
    override fun onCreate() {
        super.onCreate()
        
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                throwable.printStackTrace(PrintWriter(sw))
                
                val dataHora = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                val logCompleto = "Data: $dataHora\nThread: ${thread.name}\n\n${sw.toString()}"

                // CORREÇÃO: Usar filesDir (pasta interna) em vez da externa
                val crashFile = File(filesDir, "pcstop_crash.txt")
                crashFile.writeText(logCompleto)
                
            } catch (e: Exception) {
                Log.e("PCSTOP-APP", "Falha ao salvar o arquivo: ${e.message}")
            }

            if (defaultHandler != null) {
                defaultHandler.uncaughtException(thread, throwable)
            } else {
                android.os.Process.killProcess(android.os.Process.myPid())
                System.exit(10)
            }
        }
    }
}