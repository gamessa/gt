package com.example.pcstop

import android.content.Context
import android.system.Os
import java.io.BufferedInputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.GZIPInputStream

/**
 * Extrator de .tar e .tar.gz em Kotlin puro (sem dependências externas).
 *
 * Trata: arquivos, diretórios, links simbólicos, hard links (viram cópias),
 * nomes longos GNU (L/K), cabeçalhos pax (x/g) e tamanhos em base-256.
 * Ignora (e registra em Result.skipped): dispositivos, fifos e entradas que
 * escapariam da pasta de destino.
 *
 * NÃO suporta .xz nem .zst. Gere o arquivo com:
 *     tar --format=gnu -czf rootfs.tar.gz ...      (ou --format=pax)
 *
 * Bloqueia: chame de uma thread de fundo.
 *
 * Uso (no lugar do /system/bin/tar):
 *     val r = TarExtractor.extract(archive, rootfsDir) { pct, nome ->
 *         Log.d("PCSTOP", "$pct% $nome")
 *     }
 *     if (r.skipped.isNotEmpty()) Log.w("PCSTOP", "ignorados: ${r.skipped.take(10)}")
 */
object TarExtractor {

    class Result(
        val entries: Int,
        val files: Int,
        val dirs: Int,
        val symlinks: Int,
        val hardlinks: Int,
        val skipped: List<String>
    )

    private const val BLOCK = 512
    private const val T_REG_OLD = 0x00
    private const val T_REG = 0x30        // '0'
    private const val T_HARD = 0x31       // '1'
    private const val T_SYM = 0x32        // '2'
    private const val T_DIR = 0x35        // '5'
    private const val T_CONT = 0x37       // '7'
    private const val T_PAX_GLOBAL = 0x67 // 'g'
    private const val T_PAX = 0x78        // 'x'
    private const val T_GNU_LONGLINK = 0x4B // 'K'
    private const val T_GNU_LONGNAME = 0x4C // 'L'
    private const val MAX_EXT_HEADER = 1_048_576L

    fun extract(
        archive: File,
        targetDir: File,
        onProgress: ((percent: Int, current: String) -> Unit)? = null
    ): Result {
        val total = archive.length()
        FileInputStream(archive).use { fis ->
            return extract(fis, targetDir, total, onProgress)
        }
    }

    fun extractAsset(
        context: Context,
        assetName: String,
        targetDir: File,
        onProgress: ((percent: Int, current: String) -> Unit)? = null
    ): Result {
        context.assets.open(assetName).use { input ->
            return extract(input, targetDir, -1L, onProgress)
        }
    }

    fun extract(
        input: InputStream,
        targetDir: File,
        totalBytes: Long = -1L,
        onProgress: ((percent: Int, current: String) -> Unit)? = null
    ): Result {
        targetDir.mkdirs()
        val root = targetDir.canonicalFile

        val counting = CountingInputStream(input)
        val buffered = BufferedInputStream(counting, 1 shl 16)
        buffered.mark(2)
        val b0 = buffered.read()
        val b1 = buffered.read()
        buffered.reset()
        val stream: InputStream =
            if (b0 == 0x1f && b1 == 0x8b) GZIPInputStream(buffered, 1 shl 16) else buffered

        val header = ByteArray(BLOCK)
        val buf = ByteArray(1 shl 16)
        val skipped = ArrayList<String>()
        val deferredHard = ArrayList<Triple<File, String, Int>>()

        var entries = 0
        var files = 0
        var dirs = 0
        var syms = 0
        var hards = 0

        var longName: String? = null
        var longLink: String? = null
        var paxPath: String? = null
        var paxLink: String? = null
        var paxSize = -1L
        var lastPercent = -1

        loop@ while (true) {
            if (!readBlock(stream, header)) break
            if (isZero(header)) break
            verifyChecksum(header)

            val type = header[156].toInt() and 0xFF
            var size = parseNumber(header, 124, 12)

            // ---- cabeçalhos "meta": valem pra próxima entrada ----
            if (type == T_GNU_LONGNAME) {
                longName = cString(readData(stream, size, buf))
                continue@loop
            }
            if (type == T_GNU_LONGLINK) {
                longLink = cString(readData(stream, size, buf))
                continue@loop
            }
            if (type == T_PAX) {
                val rec = parsePax(readData(stream, size, buf))
                rec["path"]?.let { paxPath = it }
                rec["linkpath"]?.let { paxLink = it }
                rec["size"]?.toLongOrNull()?.let { paxSize = it }
                continue@loop
            }
            if (type == T_PAX_GLOBAL) {
                readData(stream, size, buf)
                continue@loop
            }

            // ---- entrada de verdade ----
            var name = readString(header, 0, 100)
            val magic = readString(header, 257, 6)
            if (magic == "ustar") {
                val prefix = readString(header, 345, 155)
                if (prefix.isNotEmpty()) name = "$prefix/$name"
            }
            var link = readString(header, 157, 100)

            longName?.let { name = it }
            paxPath?.let { name = it }
            longLink?.let { link = it }
            paxLink?.let { link = it }
            if (paxSize >= 0) size = paxSize
            longName = null
            longLink = null
            paxPath = null
            paxLink = null
            paxSize = -1L

            entries++
            val mode = parseNumber(header, 100, 8).toInt()
            val noData = type == T_HARD || type == T_SYM || type == T_DIR
            val rel = cleanName(name)

            if (rel.isEmpty()) {
                if (!noData) skipData(stream, size + padding(size), buf)
                continue@loop
            }

            val dest = File(root, rel)
            if (!parentInside(root, dest)) {
                skipped.add("fora da raiz: $rel")
                if (!noData) skipData(stream, size + padding(size), buf)
                continue@loop
            }

            if (type == T_DIR) {
                if (dest.exists() && !dest.isDirectory) deleteExisting(dest)
                dest.mkdirs()
                chmodSafe(dest, mode, true)
                dirs++
            } else if (type == T_REG_OLD || type == T_REG || type == T_CONT) {
                dest.parentFile?.mkdirs()
                deleteExisting(dest)
                FileOutputStream(dest).use { out -> copyN(stream, out, size, buf) }
                skipData(stream, padding(size), buf)
                chmodSafe(dest, mode, false)
                files++
            } else if (type == T_SYM) {
                dest.parentFile?.mkdirs()
                deleteExisting(dest)
                try {
                    Os.symlink(link, dest.path)
                    syms++
                } catch (e: Exception) {
                    skipped.add("symlink falhou: $rel -> $link (${e.message})")
                }
            } else if (type == T_HARD) {
                val targetRel = cleanName(link)
                val target = File(root, targetRel)
                if (target.isFile && selfInside(root, target)) {
                    copyHard(target, dest, mode)
                    hards++
                } else {
                    deferredHard.add(Triple(dest, targetRel, mode))
                }
            } else {
                // dispositivos, fifos, sparse etc.
                skipped.add("tipo $type ignorado: $rel")
                skipData(stream, size + padding(size), buf)
            }

            if (onProgress != null && totalBytes > 0) {
                val pct = (counting.count * 100 / totalBytes).toInt().coerceIn(0, 99)
                if (pct != lastPercent || entries % 500 == 0) {
                    lastPercent = pct
                    onProgress(pct, rel)
                }
            }
        }

        // hard links cujo alvo só apareceu depois
        for ((dest, targetRel, mode) in deferredHard) {
            val target = File(root, targetRel)
            if (target.isFile && selfInside(root, target)) {
                copyHard(target, dest, mode)
                hards++
            } else {
                skipped.add("hardlink sem alvo: ${dest.name} -> $targetRel")
            }
        }

        onProgress?.invoke(100, "concluído")
        return Result(entries, files, dirs, syms, hards, skipped)
    }

    // ---------------------------------------------------------------
    //  Auxiliares
    // ---------------------------------------------------------------

    private fun cleanName(n: String): String {
        var s = n
        while (s.startsWith("./")) s = s.substring(2)
        s = s.trimStart('/').trimEnd('/')
        return if (s == ".") "" else s
    }

    /** O diretório pai (com links resolvidos) precisa estar dentro da raiz. */
    private fun parentInside(root: File, f: File): Boolean {
        val p = (f.parentFile ?: f).canonicalFile.path
        val r = root.path
        return p == r || p.startsWith(r + File.separator)
    }

    private fun selfInside(root: File, f: File): Boolean {
        val p = f.canonicalFile.path
        return p.startsWith(root.path + File.separator)
    }

    private fun deleteExisting(f: File) {
        try { Os.remove(f.path) } catch (_: Exception) {}
    }

    private fun copyHard(src: File, dest: File, mode: Int) {
        dest.parentFile?.mkdirs()
        deleteExisting(dest)
        src.copyTo(dest, overwrite = true)
        chmodSafe(dest, mode, false)
    }

    private fun chmodSafe(f: File, mode: Int, isDir: Boolean) {
        try {
            // 0x1FF = 0777, 0x1C0 = 0700, 0x180 = 0600 (o dono sempre consegue ler/escrever)
            val m = (mode and 0x1FF) or (if (isDir) 0x1C0 else 0x180)
            Os.chmod(f.path, m)
        } catch (_: Exception) {}
    }

    private fun padding(size: Long): Long = (BLOCK - (size % BLOCK)) % BLOCK

    private fun readBlock(s: InputStream, buf: ByteArray): Boolean {
        var n = 0
        while (n < BLOCK) {
            val r = s.read(buf, n, BLOCK - n)
            if (r < 0) {
                if (n == 0) return false
                throw EOFException("Arquivo truncado no cabeçalho do tar")
            }
            n += r
        }
        return true
    }

    private fun isZero(h: ByteArray): Boolean {
        for (i in 0 until BLOCK) if (h[i].toInt() != 0) return false
        return true
    }

    private fun verifyChecksum(h: ByteArray) {
        val stored = parseNumber(h, 148, 8)
        var unsigned = 0L
        var signed = 0L
        for (i in 0 until BLOCK) {
            if (i in 148..155) {
                unsigned += 0x20
                signed += 0x20
            } else {
                unsigned += (h[i].toInt() and 0xFF)
                signed += h[i].toInt()
            }
        }
        if (unsigned != stored && signed != stored) {
            throw IOException("Cabeçalho tar inválido (checksum). Arquivo corrompido ou formato não suportado (use .tar ou .tar.gz)")
        }
    }

    private fun parseNumber(buf: ByteArray, off: Int, len: Int): Long {
        if ((buf[off].toInt() and 0x80) != 0) {
            var v = (buf[off].toInt() and 0x7F).toLong()
            for (i in 1 until len) v = (v shl 8) or (buf[off + i].toLong() and 0xFF)
            return v
        }
        var v = 0L
        var i = off
        val end = off + len
        while (i < end && (buf[i].toInt() == 0x20 || buf[i].toInt() == 0)) i++
        while (i < end) {
            val c = buf[i].toInt()
            if (c < 0x30 || c > 0x37) break
            v = v * 8 + (c - 0x30)
            i++
        }
        return v
    }

    private fun readString(buf: ByteArray, off: Int, len: Int): String {
        var end = off
        val max = off + len
        while (end < max && buf[end].toInt() != 0) end++
        return String(buf, off, end - off, Charsets.UTF_8)
    }

    private fun cString(b: ByteArray): String {
        var end = 0
        while (end < b.size && b[end].toInt() != 0) end++
        return String(b, 0, end, Charsets.UTF_8)
    }

    private fun readData(s: InputStream, size: Long, buf: ByteArray): ByteArray {
        if (size < 0 || size > MAX_EXT_HEADER) {
            throw IOException("Cabeçalho estendido inválido ($size bytes)")
        }
        val data = ByteArray(size.toInt())
        var n = 0
        while (n < data.size) {
            val r = s.read(data, n, data.size - n)
            if (r < 0) throw EOFException("Arquivo truncado")
            n += r
        }
        skipData(s, padding(size), buf)
        return data
    }

    private fun skipData(s: InputStream, n: Long, buf: ByteArray) = copyN(s, null, n, buf)

    private fun copyN(s: InputStream, out: OutputStream?, n: Long, buf: ByteArray) {
        var left = n
        while (left > 0) {
            val want = if (left < buf.size) left.toInt() else buf.size
            val r = s.read(buf, 0, want)
            if (r < 0) throw EOFException("Arquivo truncado dentro de uma entrada do tar")
            out?.write(buf, 0, r)
            left -= r
        }
    }

    /** Registros pax: "<tamanho> chave=valor\n" */
    private fun parsePax(data: ByteArray): Map<String, String> {
        val map = HashMap<String, String>()
        var pos = 0
        while (pos < data.size) {
            var sp = pos
            while (sp < data.size && data[sp].toInt() != 0x20) sp++
            if (sp >= data.size) break
            val recLen = String(data, pos, sp - pos, Charsets.US_ASCII).toIntOrNull() ?: break
            if (recLen <= 0 || pos + recLen > data.size) break
            val kv = String(data, sp + 1, pos + recLen - sp - 2, Charsets.UTF_8)
            val eq = kv.indexOf('=')
            if (eq > 0) map[kv.substring(0, eq)] = kv.substring(eq + 1)
            pos += recLen
        }
        return map
    }

    /** Conta os bytes lidos do arquivo (comprimido), pra calcular o progresso. */
    private class CountingInputStream(input: InputStream) : FilterInputStream(input) {
        @Volatile
        var count = 0L

        override fun read(): Int {
            val r = super.read()
            if (r >= 0) count++
            return r
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = super.read(b, off, len)
            if (r > 0) count += r
            return r
        }
    }
}
