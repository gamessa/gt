package com.example.pcstop

import android.content.Context
import org.json.JSONObject
import java.io.File

data class ContainerConfig(
    val id: String,
    val name: String,
    var enableAudio: Boolean = true
) {
    // Salva os dados do container (usado pela ContainerConfigActivity)
    fun save(context: Context) {
        val prefs = context.getSharedPreferences("pcstop_containers", Context.MODE_PRIVATE)
        val json = JSONObject()
        json.put("id", id)
        json.put("name", name)
        json.put("enableAudio", enableAudio)
        
        prefs.edit().putString(id, json.toString()).apply()
    }

    // Retorna o diretório raiz onde o rootfs e arquivos do container ficam
    fun rootDir(context: Context): File {
        return File(context.filesDir, "containers/$id")
    }

    companion object {
        // Carrega um container específico pelo ID (usado pela XServerActivity)
        fun load(context: Context, id: String): ContainerConfig {
            val prefs = context.getSharedPreferences("pcstop_containers", Context.MODE_PRIVATE)
            val jsonStr = prefs.getString(id, null)
            if (jsonStr != null) {
                try {
                    val json = JSONObject(jsonStr)
                    return ContainerConfig(
                        id = json.getString("id"),
                        name = json.getString("name"),
                        enableAudio = json.optBoolean("enableAudio", true)
                    )
                } catch (e: Exception) {
                    // Ignora erro e cria um padrão
                }
            }
            // Fallback caso não ache o container
            return ContainerConfig(id, "Debian Linux", true)
        }

        // Retorna todos os containers salvos (usado pela MainActivity)
        fun getAll(context: Context): List<ContainerConfig> {
            val prefs = context.getSharedPreferences("pcstop_containers", Context.MODE_PRIVATE)
            val list = mutableListOf<ContainerConfig>()
            
            for (key in prefs.all.keys) {
                if (key != "null") {
                    val jsonStr = prefs.getString(key, null)
                    if (jsonStr != null) {
                        try {
                            val json = JSONObject(jsonStr)
                            list.add(
                                ContainerConfig(
                                    id = json.getString("id"),
                                    name = json.getString("name"),
                                    enableAudio = json.optBoolean("enableAudio", true)
                                )
                            )
                        } catch (e: Exception) {}
                    }
                }
            }
            return list
        }

        // Deleta o container (usado pela MainActivity)
        fun delete(context: Context, id: String) {
            // Remove do SharedPreferences
            val prefs = context.getSharedPreferences("pcstop_containers", Context.MODE_PRIVATE)
            prefs.edit().remove(id).apply()

            // Apaga a pasta física do container
            val containerDir = File(context.filesDir, "containers/$id")
            if (containerDir.exists()) {
                containerDir.deleteRecursively()
            }
        }
    }
}