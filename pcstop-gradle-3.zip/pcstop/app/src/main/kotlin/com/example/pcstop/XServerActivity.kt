package com.example.pcstop

import android.app.Activity
import android.content.res.ColorStateList
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import com.termux.x11.CmdEntryPoint
import com.termux.x11.LorieView
import java.io.File

class XServerActivity : Activity() {

    private lateinit var config: ContainerConfig
    private lateinit var executor: ContainerExecutor
    private lateinit var logView: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var vncPanel: FrameLayout
    private lateinit var logPanel: LinearLayout

    private lateinit var lorieView: LorieView
    private var serverProcess: Process? = null

    private var logVisible = false
    private val logLock = Any()
    private val logBuffer = StringBuilder()
    private var logScheduled = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var bootOverlay: LinearLayout
    private lateinit var bootProgressBar: ProgressBar
    private lateinit var bootStepText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        vncPanel = FrameLayout(this)
        root.addView(vncPanel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        logPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC000000.toInt())
            visibility = View.GONE
        }
        logScroll = ScrollView(this)
        logView = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 12f
            setPadding(16, 16, 16, 16)
        }
        logScroll.addView(logView)
        logPanel.addView(logScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val lp = FrameLayout.LayoutParams((300 * resources.displayMetrics.density).toInt(), ViewGroup.LayoutParams.MATCH_PARENT)
        lp.gravity = Gravity.END
        root.addView(logPanel, lp)

        val btnToggleLog = Button(this).apply {
            text = "LOG"
            setOnClickListener {
                logVisible = !logVisible
                logPanel.visibility = if (logVisible) View.VISIBLE else View.GONE
            }
        }
        val btnParams = FrameLayout.LayoutParams(150, 120)
        btnParams.gravity = Gravity.TOP or Gravity.END
        root.addView(btnToggleLog, btnParams)

        setContentView(root)

        setupBootOverlay()
        vncPanel.addView(bootOverlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val containerId = intent.getStringExtra("containerId") ?: run { finish(); return }
        config = ContainerConfig.load(this, containerId)
        executor = ContainerExecutor(this, config)

        executor.onProgress = { text, pct -> setBootStep(text, pct) }
        executor.onLog = { msg -> log("$msg\n") }

        // 1. Carrega a biblioteca nativa do Termux-X11
        try {
            System.loadLibrary("Xlorie")
            log("✅ libXlorie.so carregada!\n")
        } catch (e: Throwable) {
            log("❌ Erro ao carregar libXlorie: ${e.message}\n")
            setBootError("Erro Crítico: ${e.message}")
            return
        }

        // 2. Cria a View do Termux-X11
        try {
            lorieView = LorieView(this)
            lorieView.isClickable = true
            lorieView.isFocusable = true
            lorieView.isFocusableInTouchMode = true
            lorieView.requestFocus()
            
            vncPanel.addView(lorieView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            log("✅ LorieView iniciada!\n")
        } catch (e: Throwable) {
            log("❌ Erro na LorieView: ${e.message}\n")
            setBootError("Erro na LorieView: ${e.message}")
            return
        }

        setBootStep("Iniciando boot...", null)
        Thread { bootSequence() }.start()
    }

    private fun bootSequence() {
        try {
            log("Iniciando boot...\n")
            if (!executor.prepare()) {
                log("X ${executor.lastError}\n")
                setBootError("Falha: ${executor.lastError}")
                return
            }
            log("OK Rootfs extraido\n\n")

            log("Iniciando Servidor X11 Nativo (CmdEntryPoint)...\n")
            // Inicia o CmdEntryPoint na thread separada
            Thread {
                try {
                    CmdEntryPoint.main(arrayOf(":0"))
                    log("OK CmdEntryPoint iniciado.\n")
                } catch (e: Exception) {
                    log("X Erro ao iniciar CmdEntryPoint: ${e.message}\n")
                    Log.e("PCSTOP", "Erro CmdEntryPoint", e)
                }
            }.start()

            Thread.sleep(2000)

            log("Iniciando IceWM no Debian...\n")
            launchIceWM()
            
            log("✅ Boot finalizado!\n")
            mainHandler.post { hideBootOverlay() }

        } catch (e: Exception) {
            log("X boot exception: ${e.message}\n")
            setBootError("Erro: ${e.message}")
        }
    }

    private fun launchIceWM() {
        val bootCmd = """
            export DISPLAY=:0
            export XDG_RUNTIME_DIR=/tmp
            export HOME=/root
            
            mkdir -p /tmp/.X11-unix
            chmod 1777 /tmp/.X11-unix
            
            # Inicia o IceWM e o xterm
            icewm > /tmp/icewm.log 2>&1 &
            ICEWM_PID=${'$'}!
            sleep 2
            xterm -e "echo 'Termux-X11 Embutido!'; sleep 60" > /tmp/xterm.log 2>&1 &
            
            wait ${'$'}ICEWM_PID
        """.trimIndent()

        val shellLog = File(filesDir, "x11-server.log")
        shellLog.delete()
        serverProcess = executor.launch(shellLog, "/bin/bash", "-c", bootCmd, fakeRoot = true)
        
        log("✅ IceWM lançado!\n")
    }

    private fun setupBootOverlay() {
        bootOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xE6000000.toInt())
            visibility = View.VISIBLE
            isClickable = true
        }
        bootProgressBar = ProgressBar(this, null, android.R.attr.progressBarStyleLarge).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(0xFF1E88E5.toInt())
        }
        bootStepText = TextView(this).apply {
            text = "Preparando..."
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(48, 32, 48, 32)
        }
        bootOverlay.addView(bootProgressBar)
        bootOverlay.addView(bootStepText)
    }

    private fun setBootStep(text: String, progress: Int?) {
        mainHandler.post {
            bootOverlay.visibility = View.VISIBLE
            bootStepText.text = text
        }
    }

    private fun setBootError(text: String) {
        mainHandler.post {
            bootOverlay.visibility = View.VISIBLE
            bootStepText.setTextColor(0xFFFF5252.toInt())
            bootStepText.text = "❌ $text"
        }
    }

    private fun hideBootOverlay() {
        mainHandler.post {
            bootOverlay.visibility = View.GONE
            (bootOverlay.parent as? ViewGroup)?.removeView(bootOverlay)
        }
    }

    private fun log(text: String) {
        Log.d("PCSTOP-X", text)
        synchronized(logLock) { logBuffer.append(text) }
        scheduleLogFlush()
    }

    private fun scheduleLogFlush() {
        if (logScheduled) return
        logScheduled = true
        mainHandler.post {
            Choreographer.getInstance().postFrameCallback {
                flushLog()
                logScheduled = false
            }
        }
    }

    private fun flushLog() {
        val chunk: String
        synchronized(logLock) {
            if (logBuffer.isEmpty()) return
            chunk = logBuffer.toString()
            logBuffer.setLength(0)
        }
        logView.append(chunk)
        val sp = logView.text
        if (sp is SpannableStringBuilder && sp.length > 30_000) sp.delete(0, sp.length - 25_000)
        logScroll.post { logScroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { serverProcess?.destroy() } catch (_: Exception) {}
    }
}