package com.example.pcstop

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.TextView

class ContainerListAdapter(
    private val context: Context,
    private val items: List<ContainerConfig>,
    private val onPlay: (ContainerConfig) -> Unit,
    private val onEdit: (ContainerConfig) -> Unit,
    private val onDelete: (Int) -> Unit
) : BaseAdapter() {

    override fun getCount(): Int = items.size
    override fun getItem(position: Int): Any = items[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_container, parent, false)

        val item = items[position]

        val name = view.findViewById<TextView>(R.id.itemName)
        val btnRun = view.findViewById<Button>(R.id.itemRun)
        val btnEdit = view.findViewById<Button>(R.id.itemEdit)
        val btnDelete = view.findViewById<Button>(R.id.itemDelete)

        name.text = item.name

        btnRun.setOnClickListener { onPlay(item) }
        btnEdit.setOnClickListener { onEdit(item) }
        btnDelete.setOnClickListener { onDelete(position) }

        return view
    }
}