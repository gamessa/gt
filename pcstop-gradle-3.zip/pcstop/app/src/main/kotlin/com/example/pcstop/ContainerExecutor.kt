package com.example.pcstop

import android.content.Context
import android.os.Environment
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.file.Files
import java.nio.file.LinkOption
import java.nio.file.Paths

class ContainerExecutor(private val context: Context, private val config: ContainerConfig) {

    private val rootfsDir: File = File(config.rootDir(context), "rootfs")
    private val libsDir: File = File(context.filesDir, "proot-libs")
    private val tmpDir: File = File(context.cacheDir, "tmp")
    private val fakeFips: File = File(context.filesDir, "fake/fips_enabled")

    @Volatile
    var lastError: String = ""
        private set

    var onProgress: ((String, Int?) -> Unit)? = null
    var onLog: ((String) -> Unit)? = null

    private val prepareLock = Any()

    fun prepare(): Boolean = synchronized(prepareLock) {
        lastError = ""
        try {
            onProgress?.invoke("Preparando sistema...", null)
            ensureRootfs()
            ensureProotLibs()
            extractVortekConfig()
            setupFakeProc()
            tmpDir.mkdirs()
            tmpDir.setReadable(true, false)
            tmpDir.setWritable(true, false)
            val x11Dir = File(tmpDir, ".X11-unix")
            x11Dir.mkdirs()
            x11Dir.setReadable(true, false)
            x11Dir.setWritable(true, false)
            x11Dir.setExecutable(true, false)
            true
        } catch (t: Throwable) {
            lastError = "${t.javaClass.simpleName}: ${t.message}"
            Log.e(TAG, "prepare() falhou: $lastError", t)
            false
        }
    }

    private fun ensureRootfs() {
        val ld = File(rootfsDir, "lib/ld-linux-aarch64.so.1")
        val sh = File(rootfsDir, "bin/sh")
        if (ld.exists() && sh.exists()) return

        onProgress?.invoke("Preparando rootfs...", null)

        val importedFile = File(context.getExternalFilesDir(null), "pcstop-rootfs.tar.gz")
        val archive = if (importedFile.exists() && importedFile.length() >= MIN_ARCHIVE_SIZE) {
            logInfo("Usando rootfs importado: ${importedFile.absolutePath}")
            importedFile
        } else {
            File(context.cacheDir, "pcstop-rootfs.tar.gz")
        }

        if (!archive.exists() || archive.length() < MIN_ARCHIVE_SIZE) {
            downloadRootfs(archive)
        }

        if (rootfsDir.exists()) rootfsDir.deleteRecursively()
        rootfsDir.mkdirs()

        onProgress?.invoke("Extraindo sistema base...", 0)
        try {
            val result = TarExtractor.extract(archive, rootfsDir) { pct, name ->
                onProgress?.invoke("Extraindo: $pct% ($name)", pct)
            }
            logInfo("Extraídos: ${result.entries} entradas, arquivos: ${result.files}, ignorados: ${result.skipped.size}")
        } catch (e: Exception) {
            rootfsDir.deleteRecursively()
            throw IllegalStateException("Falha na extração: ${e.message}", e)
        }

        createFallbackSymlinks()
        fixShSymlink()

        if (archive.parentFile?.absolutePath == context.cacheDir.absolutePath) {
            archive.delete()
        }
    }

    private fun downloadRootfs(archive: File) {
        onProgress?.invoke("Baixando sistema base...", 0)
        archive.parentFile?.mkdirs()
        val part = File(archive.parentFile, "${archive.name}.part")

        try {
            var attempt = 0
            while (true) {
                try {
                    doDownload(part)
                    break
                } catch (e: IOException) {
                    part.delete()
                    if (++attempt >= MAX_DOWNLOAD_RETRIES) throw e
                    Log.w(TAG, "Download falhou (tentativa $attempt): ${e.message}")
                    Thread.sleep(1500L * attempt)
                }
            }
            if (part.length() < MIN_ARCHIVE_SIZE) {
                throw IOException("Arquivo baixado muito pequeno: ${part.length()} bytes")
            }
            if (!part.renameTo(archive)) {
                part.copyTo(archive, overwrite = true)
                part.delete()
            }
        } catch (e: Exception) {
            part.delete()
            throw IllegalStateException("Erro no download: ${e.message}", e)
        }
    }

    private fun doDownload(target: File) {
        val conn = (URL(ROOTFS_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 30_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "PCSTOP/Android")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("HTTP $code ao baixar rootfs")

            val fileLength = conn.contentLengthLong
            conn.inputStream.use { input ->
                FileOutputStream(target).use { output ->
                    val buf = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        total += n
                        output.write(buf, 0, n)
                        if (fileLength > 0) {
                            val pct = ((total * 100) / fileLength).toInt()
                            onProgress?.invoke("Baixando: $pct%", pct)
                        }
                    }
                    output.flush()
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun createFallbackSymlinks() {
        val links = mapOf("bin" to "usr/bin", "lib" to "usr/lib", "sbin" to "usr/sbin")
        for ((name, target) in links) {
            val path = File(rootfsDir, name).toPath()
            try {
                if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) {
                    Files.createSymbolicLink(path, Paths.get(target))
                    logInfo("symlink criado: $name -> $target")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Erro symlink $name: ${e.message}", e)
            }
        }
    }

    private fun fixShSymlink() {
        val binSh = File(rootfsDir, "bin/sh")
        if (!binSh.exists()) {
            val bash = File(rootfsDir, "usr/bin/bash")
            val dash = File(rootfsDir, "usr/bin/dash")
            val target = if (bash.exists()) "bash" else if (dash.exists()) "dash" else null
            if (target != null) {
                try {
                    binSh.parentFile?.mkdirs()
                    Files.createSymbolicLink(binSh.toPath(), Paths.get(target))
                    logInfo("🔗 Corrigido: bin/sh -> $target")
                } catch (e: Exception) {
                    Log.e(TAG, "Erro ao criar bin/sh: ${e.message}")
                }
            }
        }
    }

    private fun ensureProotLibs() {
        libsDir.mkdirs()
        val nativeDir = File(context.applicationInfo.nativeLibraryDir)

        val pairs = mapOf(
            "libtalloc.so"            to "libtalloc.so.2",
            "libandroid-selinux.so"   to "libandroid-selinux.so",
            "libandroid-execinfo.so"  to "libandroid-execinfo.so",
            "libandroid-glob.so"      to "libandroid-glob.so",
            "libpcre2-8.so"           to "libpcre2-8.so",
            "libandroid-shmem.so"     to "libandroid-shmem.so"
        )
        for ((src, dst) in pairs) {
            val sf = File(nativeDir, src)
            if (!sf.exists()) continue
            val df = File(libsDir, dst)
            if (!df.exists() || df.length() < sf.length()) sf.copyTo(df, overwrite = true)
        }
        logInfo("proot-libs: ${libsDir.list()?.joinToString()}")
    }

    private fun extractVortekConfig() {
        try {
            val vortekDir = File(context.filesDir, "vortek")
            vortekDir.mkdirs()
            
            val jsonFile = File(vortekDir, "vortek_icd.aarch64.json")
            if (!jsonFile.exists()) {
                context.assets.open("vortek/vortek_icd.aarch64.json").use { input ->
                    jsonFile.outputStream().use { output -> input.copyTo(output) }
                }
            }
            
            val soFile = File(vortekDir, "libvulkan_vortek.so")
            if (!soFile.exists()) {
                context.assets.open("vortek/libvulkan_vortek.so").use { input ->
                    soFile.outputStream().use { output -> input.copyTo(output) }
                }
            }
            logInfo("✅ Vortek configurado em: ${vortekDir.absolutePath}")
        } catch (e: Exception) {
            Log.e(TAG, "Erro ao extrair Vortek: ${e.message}")
        }
    }

    private fun setupFakeProc() {
        fakeFips.parentFile?.mkdirs()
        fakeFips.writeText("0\n")
    }

    fun buildProcess(command: Array<out String>, fakeRoot: Boolean): ProcessBuilder {
        val nativeDir = context.applicationInfo.nativeLibraryDir
        val prootFile = File(nativeDir, "libproot.so")
        val loaderFile = File(nativeDir, "libloader.so")

        if (!prootFile.exists()) throw IllegalStateException("libproot.so não encontrado em $nativeDir")
        if (!loaderFile.exists()) throw IllegalStateException("libloader.so não encontrado em $nativeDir")

        prootFile.setExecutable(true, false)
        loaderFile.setExecutable(true, false)
        if (!prootFile.canExecute()) throw IllegalStateException("libproot.so não executável")
        if (!loaderFile.canExecute()) throw IllegalStateException("libloader.so não executável")

        tmpDir.mkdirs()
        
        val x11Dir = File(tmpDir, ".X11-unix")
        x11Dir.mkdirs()
        val oldSocket = File(x11Dir, "X0")
        if (oldSocket.exists()) {
            oldSocket.delete()
            Log.i(TAG, "Socket antigo removido.")
        }

        val prootCmd = mutableListOf<String>().apply {
            add(prootFile.absolutePath)
            addAll(listOf("-r", rootfsDir.absolutePath, "-v", "0", "-w", "/"))
            if (fakeRoot) add("-0")
            addAll(listOf(
                "-b", "/sys", "-b", "/dev", "-b", "/proc",
                "-b", "${fakeFips.absolutePath}:/proc/sys/crypto/fips_enabled",
                "-b", "/data",
                "-b", "/storage",
                "-b", "${Environment.getExternalStorageDirectory().absolutePath}:/sdcard",
                "-b", "/mnt",
                "-b", "/proc/mounts:/etc/mtab",
                "-b", "/system",
                "-b", "/apex",
                "-b", "/linkerconfig/ld.config.txt",
                "-b", "/:/host-rootfs",
                "-b", "${tmpDir.absolutePath}:/tmp",
                "--link2symlink"
            ))
            addAll(command)
        }

        val pb = ProcessBuilder(prootCmd)
            .directory(context.filesDir)
            .redirectErrorStream(true)

        pb.environment().apply {
            put("PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin")
            put("PROOT_TMP_DIR", tmpDir.absolutePath)
            put("PROOT_LOADER", loaderFile.absolutePath)
            put("LD_LIBRARY_PATH", "${libsDir.absolutePath}:$nativeDir")
            put("TERM", "xterm-256color")
            put("HOME", "/root")
            put("USER", if (fakeRoot) "root" else "user")
            put("LANG", "C.UTF-8")
            put("LC_ALL", "C.UTF-8")
        }
        return pb
    }

    fun exec(vararg command: String, fakeRoot: Boolean = false): String {
        return try {
            val p = buildProcess(command, fakeRoot).start()
            val out = p.inputStream.bufferedReader().use { it.readText() }
            val exit = p.waitFor()
            "exit=$exit\n$out"
        } catch (t: Throwable) {
            "Erro: ${t.message}"
        }
    }

    fun launch(logFile: File, vararg command: String, fakeRoot: Boolean = false): Process {
        val pb = buildProcess(command, fakeRoot)
        pb.redirectOutput(ProcessBuilder.Redirect.appendTo(logFile))
        return pb.start()
    }

    fun startPulseAudio(): Process? = null

    private fun logInfo(msg: String) {
        Log.i(TAG, msg)
        onLog?.invoke(msg)
    }

    companion object {
        private const val TAG = "PCSTOP"
        private const val ROOTFS_URL =
            "https://github.com/gamessa/PCSTOP/releases/download/1.0.3/pcstop-rootfs.tar.gz"
        private const val MIN_ARCHIVE_SIZE = 100_000_000L
        private const val MAX_DOWNLOAD_RETRIES = 3
    }
}