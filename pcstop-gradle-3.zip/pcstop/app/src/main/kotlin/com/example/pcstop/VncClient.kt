package com.example.pcstop

import android.graphics.Bitmap
import android.util.Log
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

class VncClient(
    private val listener: Listener,
    private val debugLog: ((String) -> Unit)? = null
) {

    interface Listener {
        fun onConnected(width: Int, height: Int)
        fun onFramebufferUpdated(bitmap: Bitmap)
        fun onDisconnected(reason: String)
    }

    private var socket: Socket? = null
    private var input: DataInputStream? = null
    private var output: DataOutputStream? = null

    @Volatile private var running = false
    private var fbWidth = 0
    private var fbHeight = 0
    private var bitmap: Bitmap? = null

    private val sendExecutor = Executors.newSingleThreadExecutor()

    // 16 bytes do PixelFormat
    private val pixelFormat = byteArrayOf(
        32, 24, 0, 1,        // bpp, depth, big-endian, true-color
        0, -1, 0, -1, 0, -1, // red-max, green-max, blue-max
        16, 8, 0,            // red-shift, green-shift, blue-shift
        0, 0, 0              // padding
    )

    fun connect(host: String, port: Int) {
        if (running) return
        running = true
        Thread {
            try {
                doConnect(host, port)
            } catch (e: Exception) {
                Log.e("VncClient", "connect: ${e.message}", e)
                debugLog?.invoke("VNC erro: ${e.message}\n")
                listener.onDisconnected("${e.javaClass.simpleName}: ${e.message}")
            } finally {
                running = false
                try { socket?.close() } catch (_: Exception) {}
            }
        }.start()
    }

    private fun doConnect(host: String, port: Int) {
        val s = Socket()
        s.tcpNoDelay = true
        s.connect(InetSocketAddress(host, port), 10_000)
        socket = s
        input = DataInputStream(s.getInputStream())
        output = DataOutputStream(s.getOutputStream())

        val i = input!!
        val o = output!!

        // 1. Handshake de versão
        val serverVersion = ByteArray(12)
        i.readFully(serverVersion)
        Log.d("VncClient", "Servidor: ${String(serverVersion)}")
        debugLog?.invoke("VNC Server: ${String(serverVersion).trim()}\n")

        o.write("RFB 003.008\n".toByteArray(Charsets.US_ASCII))
        o.flush()

        // 2. Security
        val numTypes = i.readUnsignedByte()
        if (numTypes == 0) throw RuntimeException("Servidor recusou")
        val types = ByteArray(numTypes)
        i.readFully(types)
        val hasNone = types.any { it.toInt() == 1 }
        if (!hasNone) throw RuntimeException("Sem auth None")

        o.writeByte(1)
        o.flush()
        val secResult = i.readInt()
        if (secResult != 0) throw RuntimeException("Auth falhou")

        // 3. ClientInit
        o.writeByte(1)
        o.flush()

        // 4. ServerInit
        fbWidth = i.readUnsignedShort()
        fbHeight = i.readUnsignedShort()
        val spf = ByteArray(16)
        i.readFully(spf)
        val nameLen = i.readInt()
        val name = ByteArray(nameLen)
        i.readFully(name)
        Log.d("VncClient", "Desktop: ${fbWidth}x$fbHeight (${String(name)})")
        debugLog?.invoke("Desktop: ${String(name)} (${fbWidth}x$fbHeight)\n")

        bitmap = Bitmap.createBitmap(fbWidth, fbHeight, Bitmap.Config.ARGB_8888)

        (listener as? android.app.Activity)?.runOnUiThread {
            listener.onConnected(fbWidth, fbHeight)
        }

        // 5. SetPixelFormat (CORRETO — usando arraycopy)
        val pfMsg = ByteArray(20)
        pfMsg[0] = 0 // tipo
        System.arraycopy(pixelFormat, 0, pfMsg, 4, 16)
        o.write(pfMsg)
        o.flush()

        // 6. SetEncodings — só Raw
        val encMsg = ByteArray(8)
        encMsg[0] = 2 // tipo
        encMsg[2] = 0; encMsg[3] = 1 // número de encodings = 1
        // encMsg[4..7] = 0 (Raw)
        o.write(encMsg)
        o.flush()

        // 7. Framebuffer inicial
        requestFbUpdate(incremental = false)

        // 8. Loop de leitura
        while (running) {
            val msgType = i.readUnsignedByte()
            when (msgType) {
                0 -> handleFramebufferUpdate()
                2 -> i.readByte() // Bell
                3 -> handleServerCutText()
                else -> {
                    Log.w("VncClient", "Msg desconhecida: $msgType")
                    running = false
                }
            }
        }
        listener.onDisconnected("Loop encerrou")
    }

    private fun handleFramebufferUpdate() {
        val i = input!!
        i.readByte() // padding
        val numRects = i.readUnsignedShort()
        for (r in 0 until numRects) {
            val x = i.readUnsignedShort()
            val y = i.readUnsignedShort()
            val w = i.readUnsignedShort()
            val h = i.readUnsignedShort()
            val encoding = i.readInt()
            if (encoding == 0) {
                val bytes = ByteArray(w * h * 4)
                i.readFully(bytes)
                val pixels = IntArray(w * h)
                var j = 0
                for (k in 0 until w * h) {
                    val b = bytes[j].toInt() and 0xFF
                    val g = bytes[j + 1].toInt() and 0xFF
                    val rr = bytes[j + 2].toInt() and 0xFF
                    pixels[k] = (0xFF shl 24) or (rr shl 16) or (g shl 8) or b
                    j += 4
                }
                val bmp = bitmap
                if (bmp != null) {
                    bmp.setPixels(pixels, 0, w, x, y, w, h)
                    (listener as? android.app.Activity)?.runOnUiThread {
                        listener.onFramebufferUpdated(bmp)
                    }
                }
            } else {
                throw RuntimeException("Encoding $encoding nao suportado")
            }
        }
        requestFbUpdate(incremental = true)
    }

    private fun handleServerCutText() {
        val i = input!!
        i.readByte(); i.readByte(); i.readByte()
        val len = i.readInt()
        val txt = ByteArray(len)
        i.readFully(txt)
    }

    private fun requestFbUpdate(incremental: Boolean) {
        sendExecutor.execute {
            try {
                val o = output ?: return@execute
                o.writeByte(3)
                o.writeBoolean(incremental)
                o.writeShort(0); o.writeShort(0)
                o.writeShort(fbWidth); o.writeShort(fbHeight)
                o.flush()
            } catch (e: Exception) {
                Log.e("VncClient", "req: ${e.message}")
            }
        }
    }

    fun sendPointerEvent(buttonMask: Int, x: Int, y: Int) {
        sendExecutor.execute {
            try {
                val o = output ?: return@execute
                o.writeByte(5)
                o.writeByte(buttonMask and 0xFF)
                o.writeShort(x.coerceIn(0, fbWidth - 1))
                o.writeShort(y.coerceIn(0, fbHeight - 1))
                o.flush()
            } catch (e: Exception) {
                debugLog?.invoke("PTR: ${e.javaClass.simpleName}\n")
            }
        }
    }

    fun sendKeyEvent(keySym: Int, pressed: Boolean) {
        sendExecutor.execute {
            try {
                val o = output ?: return@execute
                o.writeByte(4)
                o.writeByte(if (pressed) 1 else 0)
                o.writeShort(0)
                o.writeInt(keySym)
                o.flush()
            } catch (e: Exception) {
                debugLog?.invoke("KEY: ${e.javaClass.simpleName}\n")
            }
        }
    }

    fun sendKeyTap(keySym: Int) {
        sendKeyEvent(keySym, true)
        sendKeyEvent(keySym, false)
    }

    fun sendText(text: String) {
        try {
            for (ch in text) {
                val sym = charToKeysym(ch)
                if (sym != 0) sendKeyTap(sym)
            }
        } catch (e: Exception) {
            Log.e("VncClient", "sendText: ${e.javaClass.simpleName} - ${e.message}")
        }
    }

    private fun charToKeysym(ch: Char): Int {
        return when {
            ch in 'a'..'z' -> ch.code
            ch in 'A'..'Z' -> ch.code
            ch in '0'..'9' -> ch.code
            ch == ' '  -> 0x20
            ch == '\n' -> 0xFF0D
            ch == '\t' -> 0xFF09
            ch == '.'  -> 0x2E
            ch == ','  -> 0x2C
            ch == '/'  -> 0x2F
            ch == '-'  -> 0x2D
            ch == '_'  -> 0x5F
            ch == '='  -> 0x3D
            ch == '+'  -> 0x2B
            ch == ':'  -> 0x3A
            ch == ';'  -> 0x3B
            ch == '('  -> 0x28
            ch == ')'  -> 0x29
            ch == '['  -> 0x5B
            ch == ']'  -> 0x5D
            ch == '{'  -> 0x7B
            ch == '}'  -> 0x7D
            ch == '<'  -> 0x3C
            ch == '>'  -> 0x3E
            ch == '!'  -> 0x21
            ch == '?'  -> 0x3F
            ch == '@'  -> 0x40
            ch == '#'  -> 0x23
            ch == '$'  -> 0x24
            ch == '%'  -> 0x25
            ch == '&'  -> 0x26
            ch == '*'  -> 0x2A
            ch == '|'  -> 0x7C
            ch == '\\' -> 0x5C
            ch == '~'  -> 0x7E
            ch == '`'  -> 0x60
            ch == '\'' -> 0x27
            ch == '"'  -> 0x22
            else -> 0
        }
    }

    fun disconnect() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
        sendExecutor.shutdownNow()
    }
}