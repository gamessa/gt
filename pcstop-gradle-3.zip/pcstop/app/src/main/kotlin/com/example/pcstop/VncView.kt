package com.example.pcstop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sqrt

class VncView(context: Context) : View(context) {

    @Volatile private var bitmap: Bitmap? = null
    private var fbWidth = 0
    private var fbHeight = 0
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val invMatrix = Matrix()

    var client: VncClient? = null
    var onTouchLog: ((String) -> Unit)? = null

    var stretchMode = true
    var trackpadMode = true
    var isZoomEnabled = false

    private var vCursorX = 0f
    private var vCursorY = 0f
    private var cursorInit = false

    private var touchStartTime = 0L
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moveDistance = 0f
    private var isDragging = false
    private var longPressFired = false

    private var lastTapTime = 0L
    private var isDraggingWindow = false

    private val handler = Handler(Looper.getMainLooper())
    private val longPressRunnable = Runnable {
        val c = client ?: return@Runnable
        if (trackpadMode && !isDragging) {
            longPressFired = true
            onTouchLog?.invoke("RIGHT CLICK (long press)")
            c.sendPointerEvent(4, vCursorX.toInt(), vCursorY.toInt())
            handler.postDelayed({ c.sendPointerEvent(0, vCursorX.toInt(), vCursorY.toInt()) }, 50)
        }
    }

    private val viewMatrix = Matrix()
    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                viewMatrix.postScale(detector.scaleFactor, detector.scaleFactor, detector.focusX, detector.focusY)
                postInvalidateOnAnimation()
                return true
            }
        })

    init {
        isClickable = true; isFocusable = true; isFocusableInTouchMode = true
        setWillNotDraw(false)
    }

    fun setFramebuffer(bmp: Bitmap) { bitmap = bmp; postInvalidateOnAnimation() }

    fun setSize(w: Int, h: Int) { fbWidth = w; fbHeight = h; cursorInit = false; post { resetView() } }

    fun resetView() {
        if (width == 0 || height == 0 || fbWidth == 0 || fbHeight == 0) return
        viewMatrix.reset()
        if (stretchMode) {
            viewMatrix.setScale(width.toFloat() / fbWidth, height.toFloat() / fbHeight)
        } else {
            val s = min(width.toFloat() / fbWidth, height.toFloat() / fbHeight)
            val ox = (width - fbWidth * s) / 2f
            val oy = (height - fbHeight * s) / 2f
            viewMatrix.setScale(s, s)
            viewMatrix.postTranslate(ox, oy)
        }
        postInvalidateOnAnimation()
    }

    fun toggleStretchMode() { stretchMode = !stretchMode; resetView() }
    fun toggleTrackpadMode() { trackpadMode = !trackpadMode; onTouchLog?.invoke(if (trackpadMode) "MOUSE: TRACKPAD" else "MOUSE: DIRETO") }
    fun toggleZoom() { isZoomEnabled = !isZoomEnabled; if (!isZoomEnabled) resetView() }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) { super.onSizeChanged(w, h, oldw, oldh); resetView() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = bitmap
        if (bmp == null || bmp.isRecycled) { canvas.drawColor(Color.BLACK); return }
        canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(bmp, viewMatrix, paint)
    }

    private fun ensureCursor() {
        if (!cursorInit && fbWidth > 0 && fbHeight > 0) {
            vCursorX = fbWidth / 2f; vCursorY = fbHeight / 2f; cursorInit = true
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isZoomEnabled) scaleDetector.onTouchEvent(event)
        val c = client ?: return false
        if (fbWidth == 0 || fbHeight == 0) return false
        ensureCursor()
        return if (trackpadMode) handleTrackpad(event, c) else handleDirect(event, c)
    }

    private fun handleTrackpad(event: MotionEvent, c: VncClient): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastTapTime < 300) {
                    isDraggingWindow = true; lastTapTime = 0; handler.removeCallbacks(longPressRunnable)
                    c.sendPointerEvent(1, vCursorX.toInt(), vCursorY.toInt()); return true
                }
                lastTapTime = currentTime
                touchStartTime = System.currentTimeMillis(); lastX = event.x; lastY = event.y
                moveDistance = 0f; isDragging = false; longPressFired = false
                handler.postDelayed(longPressRunnable, 600)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount > 1) { handler.removeCallbacks(longPressRunnable); return true }
                val dx = event.x - lastX; val dy = event.y - lastY
                moveDistance += sqrt(dx * dx + dy * dy)
                if (moveDistance > 15) { isDragging = true; handler.removeCallbacks(longPressRunnable) }
                val sens = 1.5f
                vCursorX = (vCursorX + dx * sens).coerceIn(0f, (fbWidth - 1).toFloat())
                vCursorY = (vCursorY + dy * sens).coerceIn(0f, (fbHeight - 1).toFloat())
                if (isDraggingWindow) c.sendPointerEvent(1, vCursorX.toInt(), vCursorY.toInt())
                else c.sendPointerEvent(0, vCursorX.toInt(), vCursorY.toInt())
                lastX = event.x; lastY = event.y
                return true
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                if (isDraggingWindow) { c.sendPointerEvent(0, vCursorX.toInt(), vCursorY.toInt()); isDraggingWindow = false; return true }
                val elapsed = System.currentTimeMillis() - touchStartTime
                if (elapsed < 300 && moveDistance < 15 && !longPressFired) {
                    c.sendPointerEvent(1, vCursorX.toInt(), vCursorY.toInt())
                    handler.postDelayed({ c.sendPointerEvent(0, vCursorX.toInt(), vCursorY.toInt()) }, 50)
                }
                isDragging = false; return true
            }
            MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(longPressRunnable); isDraggingWindow = false; isDragging = false; return true }
            MotionEvent.ACTION_POINTER_DOWN -> { handler.removeCallbacks(longPressRunnable); return true }
            MotionEvent.ACTION_POINTER_UP -> {
                if (event.pointerCount == 2 && System.currentTimeMillis() - touchStartTime < 400 && moveDistance < 30) {
                    c.sendPointerEvent(4, vCursorX.toInt(), vCursorY.toInt())
                    handler.postDelayed({ c.sendPointerEvent(0, vCursorX.toInt(), vCursorY.toInt()) }, 50)
                }
                return true
            }
        }
        return true
    }

    private fun handleDirect(event: MotionEvent, c: VncClient): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val currentTime = System.currentTimeMillis()
                val (fx, fy) = toFbCoords(event.x, event.y)
                if (currentTime - lastTapTime < 300) { isDraggingWindow = true; lastTapTime = 0; c.sendPointerEvent(1, fx, fy); return true }
                lastTapTime = currentTime
                touchStartTime = System.currentTimeMillis(); touchStartX = event.x; touchStartY = event.y; lastX = event.x; lastY = event.y
                isDragging = false; longPressFired = false; handler.postDelayed(longPressRunnable, 500)
                c.sendPointerEvent(1, fx, fy); return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount > 1) return true
                val (fx, fy) = toFbCoords(event.x, event.y)
                if (abs(event.x - touchStartX) > 15 || abs(event.y - touchStartY) > 15) { isDragging = true; handler.removeCallbacks(longPressRunnable) }
                if (isDraggingWindow) c.sendPointerEvent(1, fx, fy) else c.sendPointerEvent(if (longPressFired) 4 else 1, fx, fy)
                return true
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                val (fx, fy) = toFbCoords(event.x, event.y)
                if (isDraggingWindow) { c.sendPointerEvent(0, fx, fy); isDraggingWindow = false; return true }
                c.sendPointerEvent(0, fx, fy); isDragging = false; return true
            }
            MotionEvent.ACTION_CANCEL -> { handler.removeCallbacks(longPressRunnable); isDraggingWindow = false; return true }
        }
        return true
    }

    private fun toFbCoords(x: Float, y: Float): Pair<Int, Int> {
        val pts = floatArrayOf(x, y)
        if (!viewMatrix.invert(invMatrix)) return Pair(0, 0)
        invMatrix.mapPoints(pts)
        return Pair(pts[0].toInt().coerceIn(0, fbWidth - 1), pts[1].toInt().coerceIn(0, fbHeight - 1))
    }
}